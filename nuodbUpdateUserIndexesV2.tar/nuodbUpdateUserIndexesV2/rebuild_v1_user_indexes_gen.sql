# Copyright (C) NuoDB, Inc. 2012-2017  All Rights Reserved.
#

use system;

Select 'alter ' || 'table ' || schema || '.' || tablename || ' rebuild index "'
  || indexname  || '";'
from  system.indexstatistics
where schema != 'SYSTEM'
and   statstype != 'Ver2';
